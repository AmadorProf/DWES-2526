<?php
// ============================================================
//  EJERCICIO B — PlataformaFP
//  Archivo: cursos.php
// ============================================================

// 1. session_start()

// 2. CONTROL DE ACCESO
//    - Si no hay sesión activa: mostrar aviso y redirigir
//      con header('Refresh: 3; url=login.php')

// 3. DEFINIR CATÁLOGO DE CURSOS (mínimo 5)
//    Campos: id, nombre, modalidad, duracion_horas, precio, plazas_disponibles

// 4. PROCESAR ACCIONES POST
//
//    'inscribir':
//      - Validar que se seleccionó al menos un curso
//      - Para cada curso seleccionado, validar que plazas >= 1 y <= disponibles
//      - Guardar/acumular en $_SESSION['inscripciones']
//        Si el curso ya existe en sesión: sumar plazas (sin pasar del máximo)
//      - Mensaje de confirmación
//
//    'cancelar':
//      - Eliminar solo $_SESSION['inscripciones'] (no cerrar sesión)
//
//    'logout':
//      - session_destroy() y redirigir a login.php

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>PlataformaFP — Cursos</title>
    <link rel="stylesheet" href="css/cursos.css">
</head>
<body>

<!-- CABECERA: bienvenida con nombre completo + botón logout -->
<header>
    <h1></h1>
    <form method="POST">
        <!-- botón logout -->
    </form>
</header>

<div class="contenedor">

    <!-- CATÁLOGO DE CURSOS -->
    <div class="catalogo">
        <h2>Cursos disponibles</h2>

        <!-- MENSAJE DE CONFIRMACIÓN / ERROR (si existe) -->

        <!-- FORMULARIO DE INSCRIPCIÓN -->
        <!-- Por cada curso: tarjeta .curso con datos, etiqueta recomendado si aplica,
             checkbox name="cursos_seleccionados[]" e input de plazas name="plazas[id]" -->
        <form method="POST">
            <input type="hidden" name="accion" value="inscribir">

            <!-- Aquí el foreach de $cursos -->

            <button type="submit" class="btn-inscribir">Añadir selección</button>
        </form>
    </div>

    <!-- PANEL DE INSCRIPCIONES (siempre visible) -->
    <div class="carrito">
        <h2>🛒 Mis inscripciones</h2>

        <!-- Si vacío: mensaje .vacio -->
        <!-- Si tiene cursos: tabla con nombre / plazas / subtotal, total, botón cancelar -->

    </div>

</div>
</body>
</html>
