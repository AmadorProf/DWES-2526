<?php
// ============================================================
//  EJERCICIO B — PlataformaFP
//  Archivo: login.php
// ============================================================

// 1. session_start()

// 2. DEFINIR ARRAY DE USUARIOS (mínimo 3)
//    Campos por usuario: nombre_usuario, contrasena,
//    nombre_completo, email, modalidad_favorita
//    (valores de modalidad: presencial / online / semipresencial / intensivo)

// 3. PROCESAR FORMULARIO (REQUEST_METHOD === 'POST')
//    - Leer usuario y contraseña de $_POST
//    - Buscar coincidencia en el array de usuarios
//    - Si existe: guardar todos los datos del usuario en $_SESSION
//                 redirigir a cursos.php con header('Location: ...')
//    - Si no existe: guardar mensaje de error para mostrarlo

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>PlataformaFP — Acceso</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>

<div class="card">
    <div class="logo">🎓</div>
    <h1>PlataformaFP</h1>
    <p class="subtitulo">Formación Profesional Online</p>

    <!-- MENSAJE DE ERROR (si existe) -->


    <!-- FORMULARIO: campos usuario y contrasena -->
    <!-- El campo usuario conserva el valor introducido tras un error -->
    <form method="POST" action="login.php">

    </form>
</div>

</body>
</html>
