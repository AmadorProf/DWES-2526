<?php
// ============================================================
//  EJERCICIO A — La Taberna del Dragón
//  Archivo: taberna.php  (único archivo del ejercicio)
//
//  NORMA: No uses sesiones ni cookies.
//         Todo el estado viaja en campos <input type="hidden">.
// ============================================================

// 1. LEER ESTADO DESDE $_POST
//    - monedas  (por defecto: 100)
//    - recetas  (por defecto: 0)
//    - animo    (por defecto: 50)
//    - historial (por defecto: cadena vacía)

// 2. PROCESAR ACCIÓN (solo si REQUEST_METHOD === 'POST')
//    Según $_POST['accion']:
//
//    'explorar'  → Requisito: monedas >= 10 Y animo >= 10
//                  monedas -= 10
//                  recetas += rand(1, 5)
//                  animo   -= 5
//                  Si animo > 75: recetas += 1  (bonus ánimo alto)
//
//    'contratar' → Requisito: monedas >= 20 Y animo >= 15
//                  monedas -= rand(5, 20)
//                  40 % → recetas += 3, animo += 15
//                  60 % → animo   -= 10
//
//    'reposar'   → Sin requisito
//                  monedas += 25  (máx 100)
//                  animo   += 20  (máx 100)
//
//    Después de cada acción:
//      - Genera un mensaje narrativo (distinto según resultado)
//      - Actualiza el historial: añade la acción, máx 5 entradas (FIFO)

// 3. COMPROBAR VICTORIA Y DERROTA
//    victoria → recetas >= 8
//    derrota  → monedas <= 0 O animo <= 0

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>La Taberna del Dragón</title>
    <link rel="stylesheet" href="css/taberna.css">
</head>
<body>
<div class="contenedor">

    <h1>🐉 La Taberna del Dragón</h1>

    <!-- PANEL DE ESTADO: monedas / recetas / animo -->
    <div class="panel-estado">

    </div>

    <!-- MENSAJE NARRATIVO (si existe) -->


    <!-- VICTORIA o DERROTA (si aplica) -->
    <!-- Si victoria: mensaje + sin botones de acción -->
    <!-- Si derrota: mensaje + formulario con botón Reiniciar (hidden fields a valores iniciales) -->


    <!-- FORMULARIO DE ACCIONES (si la partida sigue activa) -->
    <!-- Campos hidden: monedas, recetas, animo, historial -->
    <!-- Botones deshabilitados (disabled) si no se cumple el requisito -->
    <form method="POST">

        <div class="acciones">
            <!-- btn-explorar -->
            <!-- btn-contratar -->
            <!-- btn-reposar -->
        </div>
    </form>

    <!-- HISTORIAL (últimas 5 acciones, siempre visible) -->
    <div class="historial">
        <h3>📋 Últimas acciones</h3>

    </div>

</div>
</body>
</html>
